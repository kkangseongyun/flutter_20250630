import 'package:flutter/material.dart';
import 'package:flutter_lab/ch4/widgets/content_widget.dart';
import 'package:flutter_lab/ch4/widgets/header_widget.dart';
import 'package:flutter_lab/ch4/widgets/icon_widget.dart';
import 'package:flutter_lab/ch4/widgets/image_widget.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Layout Test'),
        ),
        //위젯을 나열하다가.. 화면을 벗어나게 되면.. 자동 스크롤 지원하지 않는다..
        //검정색,노란색 패턴으로 뿌린다.
        //화면이 스크롤 되게 신경써줘야 한다..
        //SingleChildScrollView - 하나의 자식..
        //ListView - 여러개의 자식을 한꺼번에..
        body: SingleChildScrollView(
          child: Column(
            children: [
              HeaderWidget(),
              ImageWidget(),
              IconWidget(),
              ContentWidget(),
            ],
          ),
        )
      ),
    );
  }
}

