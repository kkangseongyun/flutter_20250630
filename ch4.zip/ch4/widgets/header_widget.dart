import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

const List<String> choices = [
  "신고", "알림설정","링크복사"
];

class HeaderWidget extends StatelessWidget {
  void select(String choice){
    Fluttertoast.showToast(
        msg: choice,
        toastLength: Toast.LENGTH_SHORT,
        //아래의 설정은 플랫폼에 따라 적용이 안될 수도 있다..
        gravity: ToastGravity.BOTTOM,
        backgroundColor: Colors.black,
        textColor: Colors.white,
        fontSize: 16.0
    );
  }
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Image.asset("images/lab_instagram_icon_0.jpg"),
        Text("instagram"),
        Spacer(),//공간만 차지하는 위젯..
        PopupMenuButton(
            onSelected: select,
            //확장 content를 결정하기 위해서.. 자동 호출...
            itemBuilder: (context){
              //이곳에서 리턴시키는 위젯으로.. 확장 메뉴를 출력..
              return choices.map<PopupMenuItem<String>>((String choice){
                return PopupMenuItem<String>(
                  value: choice,
                  child: Text(choice),
                );
              }).toList();
            }
        ),
      ],
    );
  }
}