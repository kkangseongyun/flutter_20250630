main(){
  void myFun(bool data1, {String? data2, int data3 = 0}){ }
  myFun(true);
  // myFun(true, "hello", 10);//error.. named parameter 로 선언되어 있으면 꼭 이름 명시해야..
  myFun(true, data2: "hello", data3: 10);
  myFun(true, data3: 10, data2: "world");//이름을 명시함으로..순서는 의미가 없다..
  myFun(true, data3: 20);

  void myFun2(bool data1, [String? data2, int data3 = 0]){ }
  myFun2(true);
  myFun2(true, "hello");
  myFun2(true, "hello", 10);
  // myFun2(true, 10);//error..
  // myFun2(true, data3: 10);//error...이름 명시해서 매개변수를 지정할 수 없다...

  void myFun3(int Function(int a) argFun){
    print(argFun(10));
  }
  myFun3((int arg) => arg + 10);
}