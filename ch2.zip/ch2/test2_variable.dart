main() {
  //모든 변수는 객체이다...
  int data1 = 10;
  print(data1.isEven);

  //casting... 상하위 관계에서만 논할 수 있다..
  // double data2 = data1;//error....
  double data2 = data1.toDouble();
  int data3 = 10.0.toInt();

  //String <-> int
  String data4 = "10";
  int data5 = int.parse(data4);
  String data6 = data5.toString();

  //var, dynamic
  int a = 10;
  // a = "hello";//error

  //타입 유추, 대입되는 값에 의해 타입이 결정된다.. 아래 코드는 int 타입으로 고정된다..
  var b = 10;
  // b = "hello";//error

  dynamic c = 10;
  c = "hello";
  c = true;

  //var 로 선언하면서 값 대입을 하지 않으면 dynamic 으로 유추된다..
  var d;
  d = 10;
  d = "hello";

  //dart 는 배열을 제공하지 않는다... List 가 배열이고. 배열이 List이다..
  //선언과 동시에 값 대입이 가능한 경우...
  List<int> list1 = [10, 20, 30];
  list1[0] = 100;
  print("${list1[0]}, ${list1[1]}");//100, 20
  list1.add(40);
  list1.add(50);
  list1.forEach((element){
    print(element);
  });
  //사이즈를 고정시키려면 생성자 이용.. 생성자에 사이즈 명시...
  List<int> list2 = List.filled(3, 0);//사이즈 - 초기값..

  //Unsupported operation: Cannot add to a fixed-length list
  // list2.add(10);
  list2.forEach((element){
    print(element);
  });

  Map<String, int> map = {"one": 10, "two": 20};
  print("${map['one']}");
}