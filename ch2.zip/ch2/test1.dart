// import "outer.dart";//상대경로로... 파일 명시...
import "package:flutter_lab/ch2/outer.dart";

main() {
  print(data1);
}