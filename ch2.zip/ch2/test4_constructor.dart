class User {
  String? name;
  int? age;

  //멤버 초기화....1
  User(String name, int age){
    this.name = name;
    this.age = age;
  }
  //멤버 초기화 ...2, 매개변수로 멤버 초기화 하면 된다면..
  User.one(this.name, this.age);
  //멤버 초기화...2..초기화 영역이용..
  //초기화 영역은 멤버 초기화, 다른 생성자 호출구문만..
  //매개변수를 참조해서 약간의 로직(연산, 함수 호출등)후 멤버 초기화 할때..
  User.two(String name, int age): this.name = name.toUpperCase(), this.age = age * 2;

  //다른 생성자 호출, 초기화 영역에...
  User.three(): this.one("홍길동", 20);
}

//factory 생성자....
class Singleton {
  int? data;
  //factory 생성자로 객체 생성이 안된다.. factory 생성자가 있다면.. 자신의 객체를 생성하는
  //다른 생성자가 있어야 한다..
  //private 개념으로.. 생성자 준비해서.. 외부에서 직접 생성 못하게..
  Singleton._privateConstructor();
  static final Singleton _instance = Singleton._privateConstructor();

  //factory 생성자는 외부 입장에서는 일반 생성자이고.. 객체 생성을 목적으로 호출되지만..
  //호출되었다고 객체가 생성되지 않는다.. 바디에서 코드로 적절하게 객체를 준비해서 리턴해야 한다.
  //리턴 타입은 클래스 타입의 객체..
  factory Singleton(){
    return _instance;
  }
}

class MyClass {
  final int data;
  const MyClass(this.data);
}

main(){
  User("aa", 10);
  User.three();

  var obj1 = Singleton();
  var obj2 = Singleton();
  obj1.data = 10;
  obj2.data = 20;
  print("${obj1.data}, ${obj2.data}");//20, 20

  //const 로 생성자가 선언이 되어 있다면.. 객체 생성시에도 const로..
  //생성자의 매개변수가 다르면.. 객체를 생성하고..
  //같으면 생성하지 않고.. 기존의 객체를 그대로 리턴..
  var obj3 = const MyClass(10);
  var obj4 = const MyClass(20);
  var obj5 = const MyClass(10);
  print("${obj3 == obj4}, ${obj3 == obj5}");//false, true
}