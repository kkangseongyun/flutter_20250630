import 'package:flutter/material.dart';
import 'package:flutter_lab/ch5/assets_widget.dart';
import 'package:flutter_lab/ch5/form_widget.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyAppState();
  }
}

class MyAppState extends State<MyApp>{
  int selectedIndex = 0;//선택된 탭 버튼 index...

  List<Widget> widgets= [
    AssetWidget(),
    FormWidget(),
  ];

  //bottom navigation item 클릭 이벤트..
  onItemTap(int index){
    setState(() {
      selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,//debug 띄를 출력하지 마라...
      theme: ThemeData(
        primarySwatch: Colors.pink,
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.orange,
          foregroundColor: Colors.black,
        )
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('Widget Test'),
          //PreferredSize - 상위 위젯에.. 나를 위해서 어느정도 사이즈를 확보해 줬으면 좋겠어..
          //주로 AppBar 내에서 사용..  AppBar는 기본 한줄 사이즈 정도 확보..
          bottom: PreferredSize(
              preferredSize: Size.fromHeight(48.0),
              child: Container(
                height: 48.0,
                alignment: Alignment.center,
                child: Text("AppBar Bottom Text"),
              ),
          ),
          flexibleSpace: Container(
            decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("images/big.jpeg"),
                  fit: BoxFit.fill,
              ),
            ),
          ),
          actions: [
            IconButton(onPressed: (){}, icon: Icon(Icons.add_alert)),
            IconButton(onPressed: (){}, icon: Icon(Icons.navigate_before))
          ],
        ),
        body: widgets.elementAt(selectedIndex),
        bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.shifting,//약간의 애니메이션 효과... fix
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: "first",
              backgroundColor: Colors.green,//이 아이템의 백그라운드가 아니라.. 이 아이템이 선택
              //되었을때.. navigation bar 전체의 background color
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.business),
              label: "second",
              backgroundColor: Colors.purple
            ),
          ],
          currentIndex: selectedIndex,
          selectedItemColor: Colors.amber,//여러 아이템중 선택된 아이템을 표시할 색상..
          onTap: onItemTap,
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                child: Text("Drawer Header"),
                decoration: BoxDecoration(
                  color: Colors.blue
                ),
              ),
              ListTile(
                title: Text("Item 1"),
                onTap: (){},
              ),
              ListTile(
                title: Text("Item 2"),
                onTap: (){},
              ),
            ],
          ),
        ),
      ),
    );
  }
}

