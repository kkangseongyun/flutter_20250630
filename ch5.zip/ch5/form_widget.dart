import 'package:flutter/material.dart';

class FormWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return FormWidgetState();
  }
}

class FormWidgetState extends State<FormWidget>{
  String firstName = '';
  String lastName = '';
  //임의 순간.. Form 의 State를 획득할 목적...
  //State획득을 위한 key는 GlobalKey로 선언되어야..
  var formKey = GlobalKey<FormState>();

  save(){
    print("$firstName, $lastName");
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          //일반 입력 위젯(TextField, Checkbox 등)은 안된다.. Form 과 연동 준비가 되어 있는
          //위젯을 사용해야 한다..
          TextFormField(
            decoration: InputDecoration(labelText: "FirstName"),
            //form state의 validate() 함수 호출되는 순간 자동 호출.. 매개변수가 유저 입력 데이터
            validator: (value){
              if(value?.isEmpty ?? false){
                return "enter firstname";//invalid 상황.. 에러메시지..
              }
              return null;//valid...
            },
            //form state의 save() 함수 호출되는 순간.. 자동 호출.. 매개변수가 유저 입력 데이터..
            onSaved: (value){
              setState(() {
                firstName = value ?? '';
              });
            },
          ),
          TextFormField(
            decoration: InputDecoration(labelText: "LastName"),
            //form state의 validate() 함수 호출되는 순간 자동 호출.. 매개변수가 유저 입력 데이터
            validator: (value){
              if(value?.isEmpty ?? false){
                return "enter lastname";//invalid 상황.. 에러메시지..
              }
              return null;//valid...
            },
            //form state의 save() 함수 호출되는 순간.. 자동 호출.. 매개변수가 유저 입력 데이터..
            onSaved: (value){
              setState(() {
                lastName = value ?? '';
              });
            },
          ),
          ElevatedButton(
              onPressed: (){
                //key로 state 획득...
                var form = formKey.currentState;
                if(form?.validate() ?? false){//모든 validator 함수가 null을 리턴하면 전체 true
                  form?.save();//모든 onSaved 함수 호출..
                  save();
                }
              },
              child: Text("save"),
          )
        ],
      ),
    );
  }
}