import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class AssetWidget extends StatelessWidget {
  Widget makeTextAsset(context) {
    //asset 의 text 파일을 읽어서.. Text 로 리턴...
    //asset 파일 로딩이다.. 시간이 오래 걸릴 수 있다.. 비동기..
    //시간이 오래 걸리는 부분을 기다릴 수는 없다..
    //미래에 발생하는 데이터.. - Future (data)를 먼저 리턴받고..
    //나는 리턴 받았으니까.. 움직인다.. 나중에 실제 데이터가 발생하면.. 내가 등록시킨 콜백 실행시켜주
    //FutureBuilder - Future 의 데이터로 화면을 구성하기 위한 위젯...
    return FutureBuilder(
      //Future data 지정..
      future: DefaultAssetBundle.of(context).loadString("assets/text/my_text.txt"),
      //future에 의해 데이터가 발생한 순간 자동 호출되는 함수.. 두번째 매개변수가 데이터..
      builder: (context, snapshot){
        if(snapshot.hasData){
          return Text("text assets data : ${snapshot.data}");
        }
        return Text("");
      },
    );
  }

  Widget makeJsonWidget(context){
    return FutureBuilder(
        future: DefaultAssetBundle.of(context).loadString("assets/text/data.json"),
        builder: (context, snapshot){
          if(snapshot.hasData){
            var root = json.decode(snapshot.data.toString());
            return Text("json data : ${root[0]["name"]}");
          }
          return Text("");
        }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Image.asset("assets/icon/user.png"),
        makeTextAsset(context),
        makeJsonWidget(context),
        Icon(Icons.menu),
        Icon(FontAwesomeIcons.music, size: 30, color: Colors.pink,),
        Container(
          margin: EdgeInsets.all(10.0),
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            image: DecorationImage(image: AssetImage("images/big.jpeg"), fit: BoxFit.cover),
          ),
          width: 200,
          height: 200,
        ),
      ],
    );
  }
}