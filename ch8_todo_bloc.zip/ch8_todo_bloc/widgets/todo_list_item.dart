import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_lab/ch8_todo_bloc/blocs/todosBloc.dart';
import 'package:flutter_lab/ch8_todo_bloc/events/events.dart';

import '../states/todosState.dart';


class TodoListItem extends StatelessWidget {
  final Todo todo;

  TodoListItem({required this.todo});

  @override
  Widget build(BuildContext context) {
    //add.....................
    TodosBloc bloc = BlocProvider.of<TodosBloc>(context);
    return ListTile(
      leading: Checkbox(
          value: todo.completed,
          onChanged: (bool? checked){
            //bloc 에 이벤트 발생..
            bloc.add(ToggleCompletedTodoEvent(todo));
          }
      ),
      title: Text(todo.title),
      trailing: IconButton(
          onPressed: (){
            //bloc에 이벤트 발생..
            bloc.add(DeleteTodoEvent(todo));
          },
          icon: Icon(Icons.delete, color: Colors.red,)
      ),
    );
  }
}
