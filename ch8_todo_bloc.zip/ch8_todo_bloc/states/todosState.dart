import 'package:flutter/material.dart';

//bloc 에 의해 유지되고 공개될 상태 데이터...
//특별한 작성규칙이 있지 않다..
class Todo {
  String title;
  bool completed;

  Todo({required this.title, this.completed = false});

  void toggleCompleted(){
    completed = !completed;
  }
}

class TodosState {
  List<Todo> todos;
  TodosState(this.todos);
}