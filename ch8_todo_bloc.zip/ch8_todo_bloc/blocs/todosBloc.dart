import 'package:flutter/foundation.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_lab/ch8_todo_bloc/events/events.dart';
import 'package:flutter_lab/ch8_todo_bloc/states/todosState.dart';


//제네릭 타입 : 이벤트 타입 - 상태 타입.
class TodosBloc extends Bloc<TodosEvent, TodosState>{
  //상위 생성자 호출하면서 상태 초기값 명시..
  TodosBloc(): super(TodosState([])){
    //event callback 등록..
    //제네릭 타입의 이벤트가 발생하다면...
    //event - 발생한 이벤트 정보. 이 객체로.. 이벤트시 넘어온 데이터 획득..
    //emit - 함수, 상태를 발행하는 함수..
    on<AddTodoEvent>((event, emit){
      //state : Bloc 의 변수.. 이 이벤트가 발생하기 전에 자신들이 유지하고 있던 상태를 지칭..
      //이전 상태를 복사..
      //상태는 변경하는 것이 아니라 이전 상태를 참조해서 새로운 상태를 만드는 것이다..
      List<Todo> newTodos = List.from(state.todos)
          ..add(event.todo);
      emit(TodosState(newTodos));
    });

    on<DeleteTodoEvent>((event, emit){
      List<Todo> newTodo = List.from(state.todos)
          ..remove(event.todo);
      emit(TodosState(newTodo));
    });

    on<ToggleCompletedTodoEvent>((event, emit){
      List<Todo> newTodos = List.from(state.todos);
      int index = newTodos.indexOf(event.todo);
      newTodos[index].toggleCompleted();
      emit(TodosState(newTodos));
    });
  }
  //이벤트가 발생할때마다.. 이벤트 및 상태 정보를 넘기기 위해서 호출..
  @override
  void onTransition(Transition<TodosEvent, TodosState> transition) {
    super.onTransition(transition);
    print(transition);
  }
}