//bloc에 발생시킬 이벤트....
//넘길 데이터가 있어서 클래스...
import 'package:flutter_lab/ch8_todo_bloc/states/todosState.dart';

abstract class TodosEvent{}

class AddTodoEvent extends TodosEvent {
  Todo todo;
  AddTodoEvent(this.todo);
}
class DeleteTodoEvent extends TodosEvent {
  Todo todo;
  DeleteTodoEvent(this.todo);
}
class ToggleCompletedTodoEvent extends TodosEvent {
  Todo todo;
  ToggleCompletedTodoEvent(this.todo);
}
