import 'package:flutter/material.dart';
import 'four_screen.dart';
import 'one_screen.dart';
import 'three_screen.dart';
import 'two_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: "/one",
      //이름과 route 정보를 매핑만 하면 되는 경우..
      //어디선가 이름으로 화면 전환 요청이 들어 왔을때 등록된 route 정보대로.. 전환만 시키면 되는 경우
      routes: {
        "/one": (context) => OneScreen(),
        "/two": (context) => TwoScreen(),
      },
      //화면 전환 요청이 들어왔지만.. 개발자 로직이 실행되어 화면이 전환되어야 하는 경우...
      //조건을 판단하고 동적으로 화면전환을 하고 싶거나..
      //화면 전환을 하기는 하는데.. 그전에 실행할 로직...
      //매개변수가.. 요청 정보이다...
      onGenerateRoute: (settings){
        if(settings.name == "/three"){
          //필요한 업무 진행하고...
          //무엇을 리턴시키든.. 이곳에서 리턴된 정보대로 화면은 전환된다..
          return MaterialPageRoute(
            builder: (context) => ThreeScreen(),
            settings: settings,//매개변수의 settings를 추가해 줘야.. 요청을 한 곳에서 추가한 데이터를
            //전달할 수 있다..
          );
        }else if(settings.name == "/four"){
          return MaterialPageRoute(
            builder: (context) => FourScreen(),
            settings: settings,
          );
        }
      },
    );
  }
}