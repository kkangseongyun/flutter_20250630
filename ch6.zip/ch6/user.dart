class User {
  String name;
  String address;
  User(this.name, this.address);
}