import 'package:flutter/material.dart';
import 'user.dart';

class OneScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        home: Scaffold(
          appBar: AppBar(
            title: Text('OneScreen'),
          ),
          body: Container(
            color: Colors.red,
            child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text('OneScreen', style: TextStyle(color: Colors.white,fontSize: 30),),
                    ElevatedButton(
                      onPressed: () async{
                        //two screen으로 화면 전환 시킨다..
                        //데이터 전달한다..
                        //데이터를 전달 받는다..
                        var result = await Navigator.pushNamed(
                            context,
                            "/two",
                            arguments: {
                              "arg1" : 10,
                              "arg2" : "hello",
                              "arg3" : User("kim", "seoul")
                            }
                        );
                        print("result : $result");
                       
                      },
                      child: Text('Go Two'),
                    )
                  ],
                )
            ),
          ),
        )
    );
  }
}