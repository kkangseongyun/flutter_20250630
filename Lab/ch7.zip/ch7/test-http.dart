import 'dart:convert';

import 'package:flutter/material.dart';


void main() {
  runApp(MyApp());
}



class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyAppState();
  }
}

class MyAppState extends State<MyApp> {



  onPressGet() async {
    
  }

  onPressPost() async {
    
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Test'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text('${user?.userId}'),
              Text('${user?.title}'),
              Text('${user?.body}'),
              ElevatedButton(
                onPressed: onPressGet,
                child: Text('GET'),
              ),
              ElevatedButton(
                onPressed: onPressPost,
                child: Text('POST'),
              ),

            ],
          ),
        ),
      ),
    );
  }
}
