import 'package:flutter/material.dart';

main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyAppState();
  }
}

class MyAppState extends State<MyApp>{
  //화면에 뿌릴 위젯 목록...
  List<Widget> widgets = [
    //위젯의 타입이 다르다면 state 매핑 정상....
    // MyColorWidget1(Colors.red),
    // MyColorWidget2(Colors.blue),
    //동일 타입의 위젯이 여러개 사용된 경우..
    //위젯 트리의 구조가 변경되면.. 순서로만 매핑해서 이상반응할수도...
    //키를 지정하면 키를 우선으로 매핑....
    MyColorWidget1(Colors.red, key: UniqueKey(),),
    MyColorWidget1(Colors.blue, key: UniqueKey(),),
  ];
  
  onChange(){
    setState(() {
      widgets.insert(1, widgets.removeAt(0));
    });
  }
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("key test"),),
        body: Column(
          children: [
            Row(children: widgets,),
            ElevatedButton(onPressed: onChange, child: Text("toggle"))
          ],
        ),
      ),
    );
  }
}

class MyColorWidget1 extends StatefulWidget {
  Color color;
  MyColorWidget1(this.color, {Key? key}): super(key: key);
  @override
  State<StatefulWidget> createState() {
    return MyColorWidget1State(color);
  }
}
class MyColorWidget1State extends State<MyColorWidget1> {
  Color color;
  MyColorWidget1State(this.color);
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        color: color,
        width: 150,
        height: 150,
      ),
    );
  }
}

class MyColorWidget2 extends StatefulWidget {
  Color color;
  MyColorWidget2(this.color);
  @override
  State<StatefulWidget> createState() {
    return MyColorWidget2State(color);
  }
}
class MyColorWidget2State extends State<MyColorWidget2> {
  Color color;
  MyColorWidget2State(this.color);
  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Container(
        color: color,
        width: 150,
        height: 150,
      ),
    );
  }
}