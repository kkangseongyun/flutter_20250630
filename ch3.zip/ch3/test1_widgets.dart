import 'package:flutter/material.dart';

main() => runApp(MyApp());

//화면 단위 위젯, 위젯 트리의 루트 위젯을 Stateful로 만드는 것은 좋지 않다..
//화면 갱신시 너무 많은 위젯이 다시 생성되게 된다..
class MyApp extends StatelessWidget {
  //자동 호출.. 이 함수에서 리턴되는 위젯이 이 클래스 위젯의 화면이다..
  @override
  Widget build(BuildContext context) {
    //화면 위젯 트리의 상단에 대부분 위치..
    //원한다면.. MaterialApp을 사용하지 않아도 되지만.. 사실상의 필수..
    //테마 설정, routing(화면전환)설정등..
    return MaterialApp(
      //화면의 기본 틀...
      home: Scaffold(
        appBar: AppBar(title: Text("widget test"),),
        body: Center(
          //위젯들을 위아래로 나열..
          child: Column(
            children: [
              MyStatelessWidget(),
              MyStatefulWidget(),
            ],
          ),
        ),
      ),
    );
  }
}

class MyStatelessWidget extends StatelessWidget {
  //stateless도 얼마든지.. 변수를 가질 수 있고 그 변수 값을 변경할 수 있다..
  bool favorited = false;
  int favoriteCount = 10;

  void toggleFavorite(){
    print("...............stateless...toggleFavorite");
    if(favorited){
      favoriteCount -= 1;
      favorited = false;
    }else {
      favoriteCount += 1;
      favorited = true;
    }
  }

  @override
  Widget build(BuildContext context) {
    print("stateless build......");
    //위젯들을 가로방향으로 나열..
    return Row(
      children: [
        IconButton(
            onPressed: toggleFavorite,
            icon: (favorited ? Icon(Icons.star) : Icon(Icons.star_border)),
            color: Colors.red,
        ),
        Container(
          child: Text("$favoriteCount"),
        ),
      ],
    );
  }
}

class MyStatefulWidget extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyState();
  }
}

//State 클래스를 선언하면서 제네릭 타입으로 어느 위젯의 State 인지를 타입으로 명시해야 한다..
class MyState extends State<MyStatefulWidget>{
  bool favorited = false;
  int favoriteCount = 10;

  void toggleFavorite(){
    print("...............stateful...toggleFavorite");
    //stateful 은 상태를 가지고. 그 상태가 변경되면 화면 re-rendering 가능하다..
    //모든 변수가 변경될때  re-rendering 될 필요는 없다.. re-rendering 명령을 내려야 한다..
    //화면에 반영되어야 하는 상태 값 변경은 setState() 매개변수 함수에서 변경하는 것이 좋다..
    //setState() 가 호출되면 build 함수가 다시 호출되어.. 변경된 값으로 위젯이 다시 구성되어..
    //화면이 업데이트가 되는데..
    //setState() 의 매개변수함수 내에서 상태값을 변경하지 않으면 시점 차이에 의해.. 상태값 변경전에
    //화면이 구성될 가능성이 있다..
    //setState() 함수는 매개변수 함수를 먼저 호출하고, 그 함수가 끝나면 build() 함수를 호출한다..
    setState(() {
      if(favorited){
        favoriteCount -= 1;
        favorited = false;
      }else {
        favoriteCount += 1;
        favorited = true;
      }
    });

  }

  @override
  Widget build(BuildContext context) {
    print("stateful build......");
    return Row(
      children: [
        IconButton(
          onPressed: toggleFavorite,
          icon: (favorited ? Icon(Icons.star) : Icon(Icons.star_border)),
          color: Colors.red,
        ),
        Container(
          child: Text("$favoriteCount"),
        ),
      ],
    );
  }
}