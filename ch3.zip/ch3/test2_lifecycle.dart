import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return MyAppState();
  }
}

class MyAppState extends State<MyApp>{
  int count = 0;

  void increment() {
    setState(() {
      count++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text("lifecycle test"),),
        body: Provider.value(//상위에서 데이터를 추가.. 이곳에 추가된 데이터를 하위에서 이용..
          value: count,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Text("I am parent widget"),
                    ElevatedButton(onPressed: increment, child: Text("increment"))
                  ],
                ),
                ChildWidget(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ChildWidget extends StatefulWidget {
  ChildWidget(){
    print("ChildWidget constructor...");
  }
  @override
  State<StatefulWidget> createState() {
    return ChildWidgetState();
  }
}

//WidgetsBindingObserver - 앱의 라이프사이클 감지.. 앱의 화면이 나오는지, 나오지 않는지..
class ChildWidgetState extends State<ChildWidget> with WidgetsBindingObserver{
  int count = 0;//상위의 상태 데이터...

  ChildWidgetState(){
    print("ChildWidgetState constructor....");
  }

  //상태 객체 생성후, 최초 한번..
  //상태 초기화.. 이벤트 등록
  @override
  void initState() {
    super.initState();
    print("ChildWidgetState, initState....");
    WidgetsBinding.instance.addObserver(this);//app 의 라이프사이클 콜백 함수가 현 클래스에 있다..
  }
  //initState 에서 등록한 이벤트 해제...
  @override
  void dispose() {
    super.dispose();
    WidgetsBinding.instance.removeObserver(this);
  }
  //initState 호출후 바로 호출....
  //이후.. 상위의 상태 변경시 호출... 반복 호출 가능성 있다..
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    print("ChildWidgetState, didChangeDependencies....");
    //Provider 로 상위가 공개한 상태를 획득하는 방법은 다양하다..
    //아래처럼 상태를 획득하지 않아도 더 편한 방법이 많다..
    //이곳에서는 라이프사이클 테스트 목적으로만...
    count = Provider.of<int>(context);
  }

  @override
  Widget build(BuildContext context) {
    print("ChildWidgetState... build");
    return Text("I am Child... $count");
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    switch(state){
      case AppLifecycleState.resumed:
      case AppLifecycleState.inactive:
        print("app lifecycle resume...");
        break;
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
      case AppLifecycleState.detached:
        print("app lifecycle paused");
        break;
    }
  }
}

//최초.............
//I/flutter (12581): ChildWidget constructor...
// I/flutter (12581): ChildWidgetState constructor....
// I/flutter (12581): ChildWidgetState, initState....
// I/flutter (12581): ChildWidgetState, didChangeDependencies....
// I/flutter (12581): ChildWidgetState... build

//부모의 상태 값 변경...
//I/flutter (12581): ChildWidget constructor...
// I/flutter (12581): ChildWidgetState... build
//==> widget은 매번 생성된다..(위젯은 불변)
//==>State 객체가 매번 생성되지는 않는다..